package com.elite.iptv
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Channel(val id: String, val name: String, val logo: String)

/** Compatible Xtream Codes (player_api.php). Adaptez si votre panel a une API differente. */
object Api {
    private fun base(s: String) = s.trim().trimEnd('/').let { if (it.startsWith("http")) it else "http://$it" }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 20000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    suspend fun login(server: String, user: String, pass: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val j = JSONObject(get("${base(server)}/player_api.php?username=$user&password=$pass"))
            j.optJSONObject("user_info")?.optInt("auth", 0) == 1
        } catch (e: Exception) { false }
    }

    suspend fun channels(server: String, user: String, pass: String): List<Channel> = withContext(Dispatchers.IO) {
        try {
            val a = JSONArray(get("${base(server)}/player_api.php?username=$user&password=$pass&action=get_live_streams"))
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Channel(o.optString("stream_id"), o.optString("name"), o.optString("stream_icon"))
            }
        } catch (e: Exception) { emptyList() }
    }

    fun streamUrl(server: String, user: String, pass: String, id: String) =
        "${base(server)}/live/$user/$pass/$id.m3u8"
}
