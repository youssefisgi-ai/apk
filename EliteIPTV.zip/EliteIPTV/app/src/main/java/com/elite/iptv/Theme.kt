package com.elite.iptv
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

class AppTheme(val name: String, val primary: Color, val bg: Color, val surface: Color, val dark: Boolean = true)

val Themes = listOf(
    AppTheme("Or Royal", Color(0xFFD4AF37), Color(0xFF0B0B10), Color(0xFF17171F)),
    AppTheme("Emeraude", Color(0xFF2ECC9A), Color(0xFF07130F), Color(0xFF0F211B)),
    AppTheme("Bleu Nuit", Color(0xFF4F8CFF), Color(0xFF0A0F1E), Color(0xFF141C33)),
    AppTheme("Rubis", Color(0xFFFF4D6D), Color(0xFF14090C), Color(0xFF241217)),
    AppTheme("Clair", Color(0xFF5B3CC4), Color(0xFFF6F5FB), Color(0xFFFFFFFF), dark = false),
)

@Composable
fun EliteTheme(index: Int, content: @Composable () -> Unit) {
    val t = Themes[index.coerceIn(Themes.indices)]
    val scheme = if (t.dark) darkColorScheme(primary = t.primary, background = t.bg, surface = t.surface, onPrimary = Color.Black)
    else lightColorScheme(primary = t.primary, background = t.bg, surface = t.surface)
    MaterialTheme(colorScheme = scheme, content = content)
}
