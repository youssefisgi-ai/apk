package com.elite.iptv
import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("elite", Context.MODE_PRIVATE)
    var server: String get() = sp.getString("server", "") ?: ""; set(v) = sp.edit().putString("server", v).apply()
    var user: String get() = sp.getString("user", "") ?: ""; set(v) = sp.edit().putString("user", v).apply()
    var pass: String get() = sp.getString("pass", "") ?: ""; set(v) = sp.edit().putString("pass", v).apply()
    var theme: Int get() = sp.getInt("theme", 0); set(v) = sp.edit().putInt("theme", v).apply()
    var player: Int get() = sp.getInt("player", 0); set(v) = sp.edit().putInt("player", v).apply() // 0=ExoPlayer 1=VLC
    fun logout() = sp.edit().remove("user").remove("pass").apply()
}
