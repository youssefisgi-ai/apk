package com.elite.iptv
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = Prefs(this)
        setContent {
            var theme by remember { mutableStateOf(prefs.theme) }
            var engine by remember { mutableStateOf(prefs.player) }
            var screen by remember { mutableStateOf(if (prefs.user.isNotEmpty()) "home" else "login") }
            var playing by remember { mutableStateOf<Channel?>(null) }
            EliteTheme(theme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    when {
                        screen == "login" -> LoginScreen(prefs) { screen = "home" }
                        playing != null -> PlayerScreen(
                            Api.streamUrl(prefs.server, prefs.user, prefs.pass, playing!!.id), playing!!.name, engine,
                            { engine = it; prefs.player = it }) { playing = null }
                        screen == "settings" -> SettingsScreen(theme, { theme = it; prefs.theme = it },
                            { prefs.logout(); screen = "login" }) { screen = "home" }
                        else -> HomeScreen(prefs, { playing = it }) { screen = "settings" }
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(prefs: Prefs, onOk: () -> Unit) {
    var server by remember { mutableStateOf(prefs.server) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("ELITE IPTV", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
        Text("Connexion", Modifier.padding(bottom = 24.dp))
        OutlinedTextField(server, { server = it }, label = { Text("Serveur (http://host:port)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(user, { user = it }, label = { Text("Utilisateur") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pass, { pass = it }, label = { Text("Mot de passe") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(20.dp))
        Button(onClick = {
            busy = true; err = ""
            scope.launch {
                if (Api.login(server, user, pass)) { prefs.server = server; prefs.user = user; prefs.pass = pass; onOk() }
                else err = "Identifiants ou serveur invalides"
                busy = false
            }
        }, enabled = !busy && server.isNotBlank() && user.isNotBlank(), shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(if (busy) "..." else "Se connecter") }
    }
}

@Composable
fun HomeScreen(prefs: Prefs, onPlay: (Channel) -> Unit, onSettings: () -> Unit) {
    var all by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { all = Api.channels(prefs.server, prefs.user, prefs.pass) }
    val list = all.filter { it.name.contains(q, true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Chaînes", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onSettings) { Text("⚙ Thèmes") }
        }
        OutlinedTextField(q, { q = it }, placeholder = { Text("Rechercher") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { c ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
                    .clickable { onPlay(c) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                    Spacer(Modifier.width(12.dp)); Text(c.name)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(theme: Int, onTheme: (Int) -> Unit, onLogout: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("‹ Retour") }
        Text("Thème", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp))
        Themes.forEachIndexed { i, t ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                .background(t.surface).clickable { onTheme(i) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(22.dp).clip(CircleShape).background(t.primary))
                Spacer(Modifier.width(12.dp))
                Text(t.name, color = if (t.dark) androidx.compose.ui.graphics.Color.White else androidx.compose.ui.graphics.Color.Black, modifier = Modifier.weight(1f))
                if (i == theme) Text("✓", color = t.primary)
            }
        }
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("Déconnexion") }
    }
}
