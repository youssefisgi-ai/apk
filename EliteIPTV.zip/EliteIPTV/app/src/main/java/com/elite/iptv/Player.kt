package com.elite.iptv
import android.net.Uri
import android.view.ViewGroup
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

@Composable
fun PlayerScreen(url: String, title: String, engine: Int, onEngine: (Int) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp)) {
            TextButton(onClick = onBack) { Text("‹ Retour") }
            Spacer(Modifier.weight(1f))
            FilterChip(engine == 0, { onEngine(0) }, { Text("ExoPlayer") })
            Spacer(Modifier.width(8.dp))
            FilterChip(engine == 1, { onEngine(1) }, { Text("VLC") })
        }
        Text(title, Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleMedium)
        Box(Modifier.fillMaxSize()) {
            key(engine, url) { if (engine == 0) ExoView(url) else VlcView(url) }
        }
    }
}

@Composable
private fun ExoView(url: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().apply {
        setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player
        layoutParams = ViewGroup.LayoutParams(-1, -1) } }, modifier = Modifier.fillMaxSize())
}

@Composable
private fun VlcView(url: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val vlc = remember { LibVLC(ctx, arrayListOf("--network-caching=1500")) }
    val mp = remember { MediaPlayer(vlc) }
    DisposableEffect(Unit) { onDispose { mp.stop(); mp.detachViews(); mp.release(); vlc.release() } }
    AndroidView(factory = { c -> VLCVideoLayout(c).also { v ->
        mp.attachViews(v, null, false, false)
        mp.media = Media(vlc, Uri.parse(url)).apply { setHWDecoderEnabled(true, false) }
        mp.play() } }, modifier = Modifier.fillMaxSize())
}
